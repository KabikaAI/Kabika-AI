import { Globe } from "@/components/ui/globe"
import { Button } from "@/components/ui/button"
import { MessageCircle, X } from "lucide-react"
import { useState, useEffect } from "react"

function App() {
  const [showChat, setShowChat] = useState(false)

  useEffect(() => {
    // Load Voiceflow Chat Widget
    if (showChat) {
      const script = document.createElement('script')
      script.src = "https://cdn.voiceflow.com/widget/bundle.mjs"
      script.type = "module"
      script.dataset.assistant = "YOUR_VOICEFLOW_PROJECT_ID" // Replace with your Voiceflow project ID
      document.body.appendChild(script)

      return () => {
        document.body.removeChild(script)
        // Cleanup Voiceflow widget
        const widget = document.querySelector('vf-widget')
        if (widget) {
          widget.remove()
        }
      }
    }
  }, [showChat])

  return (
    <div className="relative min-h-screen w-screen overflow-hidden bg-background">
      {/* Main Content */}
      <div className="relative flex h-screen items-center justify-center">
        <span className="pointer-events-none absolute z-10 whitespace-pre-wrap bg-gradient-to-b from-black to-gray-300/80 bg-clip-text text-center text-9xl font-semibold leading-none text-transparent dark:from-white dark:to-slate-900/10">
          KabikaAI
        </span>
        <Globe className="absolute inset-0" />
        <div className="pointer-events-none absolute inset-0 h-full bg-[radial-gradient(circle_at_50%_200%,rgba(0,0,0,0.2),rgba(255,255,255,0))]" />
      </div>

      {/* Chat Button */}
      <Button
        size="icon"
        className="fixed bottom-4 right-4 h-12 w-12 rounded-full shadow-lg"
        onClick={() => setShowChat(!showChat)}
      >
        {showChat ? (
          <X className="h-6 w-6" />
        ) : (
          <MessageCircle className="h-6 w-6" />
        )}
      </Button>
    </div>
  )
}

export default App;